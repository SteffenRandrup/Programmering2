Binomial2 er meget langsom, fordi det ekstra rekursive kald, kræver, at der laves rigtigt mange flere udregninger. Der var et slide til en af forelæsningerne, der illustrerede det meget godt.

Beklager den sene aflevering. Jeg har været uden internet indtil søndag aften
