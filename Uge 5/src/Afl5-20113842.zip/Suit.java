
public enum Suit {
	DIAMOND, CLUB, HEART, SPADE
}
