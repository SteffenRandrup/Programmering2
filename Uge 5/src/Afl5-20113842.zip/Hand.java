
public class Hand {

}
