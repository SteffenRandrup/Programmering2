Jeg kan ikke lige få min iterator til at løbe over alle elementer. Men jeg afleverer lige, sø  jeg har afleveret noget.
