
public class Driver {
	public static void main(String[] args){
		Binomial bin1 = new Binomial1();
		Binomial bin2 = new Binomial2();
		
		BinomialGUI gui1 = new BinomialGUI(bin1);
		BinomialGUI gui2 = new BinomialGUI(bin2);
	}
}
