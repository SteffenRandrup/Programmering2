
public interface Binomial {
	public long binomial(int n, int k);
}
