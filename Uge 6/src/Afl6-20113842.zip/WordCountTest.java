public class WordCountTest {
	public static void main(String[] args){
		
		for(String s : args){
			WordCount wc = new WordCount(s);
			new Thread(wc).start();
		}
	}
}
