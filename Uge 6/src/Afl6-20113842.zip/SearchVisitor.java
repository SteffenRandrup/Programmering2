public class SearchVisitor implements FileSystemVisitor<String> {

	private String navn;

	public SearchVisitor(String s) {
		navn = s;
	}

	@Override
	public String visitFile(FileNode f) {
		if (f.getName().contains(navn)) {
			return f.getName();
		} else {
			return null;
		}
	}

	@Override
	public String visitDirectory(DirectoryNode d) {
		String struktur = d.getName();

		for (FileSystemNode node : d) {
			if (node.accept(new SearchVisitor(navn)) != null) {
				struktur = struktur + "/" + node.accept(new SearchVisitor(navn))+"\n";
			}
		}

		//System.out.println(struktur);
		return struktur;
	}

}
