import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.BlockingQueue;

public class WordCount implements Runnable {
	
	private BlockingQueue<String> queue;
	private Scanner sc;
	private File file;
	private int count;
	
	public WordCount(String text){
		file = new File(text);
	}

	@Override
	public void run() {
		try {
			sc = new Scanner(new FileInputStream(file));
			
			while(sc.hasNext()){
			    sc.next();
			    count++;
			}
			
			System.out.println("Number of words in "+file+": " + count);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}









