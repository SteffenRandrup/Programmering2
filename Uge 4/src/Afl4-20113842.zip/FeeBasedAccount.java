
public class FeeBasedAccount implements Account {

	private int balance;
	private int transactions;
	
	@Override
	public void deposit(int amount) {
		balance += amount;
		transactions++;
	}

	@Override
	public boolean withdraw(int amount) {
		balance -= amount;
		transactions++;
		return true;
	}

	@Override
	public int getBalance() {
		return balance;
	}

	@Override
	public void yearEnd() {
		balance -= transactions;
		transactions = 0;
	}

}
