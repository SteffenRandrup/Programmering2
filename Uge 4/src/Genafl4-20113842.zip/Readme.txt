Ændringer:
	- Tilføjer abstract class AbstractAccount implements Account. Denne indeholder metoder, der går igen samt den totale "balance"
	- AccountWithInterest og FeeBasedAccount extends AbstractAccount istedet for implements Account. 
